import { Product } from "./Product"

export type Cart = {
    product: Product,
    quantity:number
}