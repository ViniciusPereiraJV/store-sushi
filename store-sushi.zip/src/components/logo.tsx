export const Logo = ()=>{
    return(
        <div className="text-xl">
            <span className="font-bold">SushiTime</span>
        </div>
    )
}