import { Footer } from "@/components/footer";
import { Header } from "@/components/header";
import { ProdutcsTab } from "@/components/products/tab";
import { TabsSkeleton } from "@/components/products/tabsSkeleton";
import { ModeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { Suspense } from "react";


export default function Home() {
  return (
   <div className="w-full max-w-4xl mx-auto">
    <Header/>
    <div className="mx-2">
      <Suspense fallback={<TabsSkeleton/>}>
      <ProdutcsTab/>
      </Suspense>
    </div>
    <Footer/>
   </div>
  );
}
